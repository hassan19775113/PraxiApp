"""Legacy prod settings module (compatibility shim).

Prefer ``praxi_backend.settings.prod``.
"""

from praxi_backend.settings.prod import *  # noqa
