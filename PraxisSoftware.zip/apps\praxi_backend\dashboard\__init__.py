# Dashboard App for PraxiApp Admin
default_app_config = "praxi_backend.dashboard.apps.DashboardConfig"
