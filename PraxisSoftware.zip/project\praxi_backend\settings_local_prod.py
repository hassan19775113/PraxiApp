"""Legacy local-prod settings module (compatibility shim).

Prefer ``praxi_backend.settings.local``.
"""

from praxi_backend.settings.local import *  # noqa
