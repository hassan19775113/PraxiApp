"""Modular settings package.

Use one of:
- praxi_backend.settings.dev
- praxi_backend.settings.prod
- praxi_backend.settings.local

Legacy modules (praxi_backend.settings_dev etc.) remain as compatibility shims.
"""
