"""
Dashboard Admin Integration
"""

# Dashboard benötigt keine eigenen Models
# Die Admin-Integration erfolgt über die CustomAdminSite in core/admin.py
